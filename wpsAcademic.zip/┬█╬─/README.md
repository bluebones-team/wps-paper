# 功能简介[2023.4.13]
## 索引格式检查
检查参考文献是否按APA格式进行索引
> 打开段落标记开关，养成排版好习惯  

## 上下文核对
核对正文和参考文献部分的索引是否相对应  

## 创建框架
根据文档大纲级别创建树形结构数据`json文件`  
该文件可以通过[汇报](../%E6%B1%87%E6%8A%A5/)加载项导入生成幻灯片

## 识别大纲
对类似于 `1. 标题` 的段落文本进行识别并添加样式

# `jspluginonline`标签
> \<jspluginonline name="论文" type="wps" url="https://cubxx.github.io/wps-addon/论文/wps-addon-build/"/>

