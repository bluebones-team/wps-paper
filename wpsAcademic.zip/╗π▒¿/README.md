# 功能简介[2023.4.13]
## 导入框架
通过[论文](../论文)加载项创建的框架文件生成幻灯片  

# `jspluginonline`标签
> \<jspluginonline name="汇报" type="wpp" url="https://cubxx.github.io/wps-addon/汇报/wps-addon-build/"/>
